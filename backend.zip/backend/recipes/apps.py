from django.apps import AppConfig


class RecipesConfig(AppConfig):
    """Регистрация приложения recipes."""

    name = 'recipes'
    verbose_name = 'рецепты'
