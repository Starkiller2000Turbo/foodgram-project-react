from django.apps import AppConfig


class UsersConfig(AppConfig):
    """Регистрация приложения users."""

    name = 'users'
    verbose_name = 'пользователи'
