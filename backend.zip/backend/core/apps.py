from django.apps import AppConfig


class CoreConfig(AppConfig):
    """Регистрация приложения core."""

    name = 'core'
    verbose_name = 'приложение с общими функциями и переменными'
