from django.apps import AppConfig


class ApiConfig(AppConfig):
    """Регистрация приложения api."""

    name = 'api'
    verbose_name = 'приложение api'
